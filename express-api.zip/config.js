module.exports = {
  PORT: process.env.PORT || 3001,
  SERVER: "127.0.0.1",
  credentials: process.env.CREDENTIALS || '*'
};
